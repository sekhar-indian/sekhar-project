package com.cbozan.view.helper;

public interface Observer {
	void update();
}
